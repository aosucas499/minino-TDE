#!/bin/sh
RUTA=/etc/NetworkManager/system-connections
FICHERO=/usr/share/cga-andared-config/Andared
if [ ! -f $RUTA/Andared ]
then
	cp $FICHERO $RUTA
	chmod 600 $RUTA/Andared
else
	/usr/bin/md5sum -c $FICHERO.md5
	if [ $? -ne 0 ]
	then
		cp $FICHERO $RUTA
		chmod 600 $RUTA/Andared
	fi
fi
